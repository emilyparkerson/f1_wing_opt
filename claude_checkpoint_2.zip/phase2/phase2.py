''' Goal is to have a config dictionary that mirrors phase1 but also includes multiple elements.
Then the optimizer reads elements and route to a single or multi mses automatically
'''

from pathlib import Path
from setup.scoring import scoring_p2
from setup.constraints import airfoil_constraints
from setup.geometry import plot_airfoil
from setup.design_vars import (
    designParameters,
    airfoilBounds
)

from setup.geometry import plot_airfoil

HERE = Path(__file__).parent

P2_RE_IB_CONFIG = {

    # Phase info
    "phase_name": "Phase 2 Rear Element Inboard Configuration",
    "scoring_function": scoring_p2,
    "plotting": True,
    "logging": True,
    "plot_geometry": True,

    # Flow conditions
    "alpha": 0.0,
    "mach": 0.093871421,
    "reynolds": 907997.7149,

    # Training data
    "training_n":5,

    # Initial design for the morph element
    "seed_airfoil": HERE / "inboard_seed_phase2.txt",
    "winner_output": HERE / "phase2_winner_IB.dat",
    "seed_design": designParameters(
        max_camber=0.04358,
        max_camber_loc=0.635,
        max_thickness=0.17569,
        max_thickness_loc=0.2434),

    # Two-element layour
    "elements": [
        {"role": "fixed",
         "coords_path": HERE / "phase1_winner_IB.dat",
         "place": "main",
         "aoa_deg": 0.0},
        {"role": "morph",
         "seed_airfoil": HERE / "inboard_seed_phase2.txt",
         "place": "second",
         "te_offset": (0.05, 0.05), # relative to 1st element
         "inherit_te_aoa": True
         },
    ],

    # Design variable bounds
    "bounds": airfoilBounds(
        max_camber=(0.00, 0.15),
        max_camber_loc=(0.30, 0.70),
        max_thickness=(0.06, 0.25),
        max_thickness_loc=(0.15, 0.45)),
    "constraints": airfoil_constraints,

    #Reference values
    "ref_vals": {
        "df": 1.2,
        "cd": 0.4
    },

    # Bayesian optimization settings
    "bo": {"training_csv": HERE / "training_data_p2.csv",
        "bounds_csv": HERE / "design_variable_bounds_p2.csv",
        "max_iter": 5},

    # Random/local search settings
    "random_search": {"n_iterations": 5,
        "step_size": {
            "max_camber": 0.003,
            "max_camber_loc": 0.02,
            "max_thickness": 0.005,
            "max_thickness_loc": 0.01}}
}




P2_RE_OB_CONFIG = {

    # Phase info
    "phase_name": "Phase 2 Rear Element Outboard Configuration",
    "scoring_function": scoring_p2,
    "plotting": True,
    "logging": True,
    "plot_geometry": True,

    # Flow conditions
    "alpha": 0.0,
    "mach": 0.122440983,
    "reynolds": 1184344.846,

    # Training data
    "training_n":5,

    # Initial design for the morph element
    "seed_airfoil": HERE / "outboard_seed_phase2.txt",
    "winner_output": HERE / "phase2_winner_OB.dat",
    "seed_design": designParameters(
        max_camber=0.02544,
        max_camber_loc=0.6616,
        max_thickness=0.1421,
        max_thickness_loc=0.2919),

    # Two-element layour
    "elements": [
        {"role": "fixed",
         "coords_path": HERE / "phase1_winner_OB.dat",
         "place": "main",
         "aoa_deg": 0.0},
        {"role": "morph",
         "seed_airfoil": HERE / "outboard_seed_phase2.txt",
         "place": "second",
         "te_offset": (0.05, 0.05), # relative to 1st element
         "inherit_te_aoa": True
         },
    ],

    # Design variable bounds
    "bounds": airfoilBounds(
        max_camber=(0.00, 0.15),
        max_camber_loc=(0.30, 0.70),
        max_thickness=(0.06, 0.25),
        max_thickness_loc=(0.15, 0.45)),
    "constraints": airfoil_constraints,

    #Reference values
    "ref_vals": {
        "df": 1.2,
        "cd": 0.4
    },

    # Bayesian optimization settings
    "bo": {"training_csv": HERE / "training_data_p2.csv",
        "bounds_csv": HERE / "design_variable_bounds_p2.csv",
        "max_iter": 5},


    # Random/local search settings
    "random_search": {"n_iterations": 5,
        "step_size": {
            "max_camber": 0.003,
            "max_camber_loc": 0.02,
            "max_thickness": 0.005,
            "max_thickness_loc": 0.01}}
}