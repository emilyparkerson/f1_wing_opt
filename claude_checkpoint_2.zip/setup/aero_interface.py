"""
---------------------------------------------------------------------
AERO INTERFACE
---------------------------------------------------------------------
Build morphed geometry via geometry.py, run MSES through pymead,
return Cl/Cd.

Geometry API used (the get_seed / new_airfoil / get_coords flow):
    load_airfoil_dat -> get_seed -> new_airfoil -> get_coords

Seeds are in inverted (rear-wing / downforce) orientation; that is
preserved to MSES. Scoring uses df = -cl.
"""

import os
import tempfile
import numpy as np
import matplotlib.pyplot as plt

from pymead.analysis.calc_aero_data import (
    calculate_aero_data,
    MSETSettings,
    MSESSettings,
    AirfoilMSETMeshingParameters,
)
from pymead.core.geometry_collection import GeometryCollection

from setup.design_vars import AeroResult
from setup.geometry import (
    load_airfoil_dat,
    get_seed,
    new_airfoil,
    get_coords,
    scale_airfoil,
    translate_airfoil,
    rotate_airfoil_phase3,
)
from setup.track import SECOND_ELM_LOC


# Shared MSES-settings / run / failure-check block
def _run_mses_on_mea(mea, pymead_coords, names, name, alpha, mach, reynolds,
                     target_cl=None):
    mset = MSETSettings(
        multi_airfoil_grid={nm: AirfoilMSETMeshingParameters() for nm in names},
        airfoil_side_points=120,
    )
    if target_cl is None:
        mses = MSESSettings(
            xtrs={nm: [0.05, 0.05] for nm in names},
            Ma=mach, Re=reynolds, alfa=alpha,
            alfa_Cl_mode=0,
            timeout=800.0,
        )
    else:
        mses = MSESSettings(
            xtrs={nm: [0.05, 0.05] for nm in names},
            Ma=mach, Re=reynolds,
            alfa=alpha,        # initial guess
            Cl=target_cl,      # target
            alfa_Cl_mode=0,
            timeout=800.0,
        )
    # pymead 2.0.0b13 bug workaround: consumer reads capitalized keys.
    mplot = {
        "timeout":         15.0,
        "grid_stats":      False,
        "Mach":            False,
        "Streamline_Grid": False,
        "Grid":            False,
        "Grid_Zoom":       False,
        "flow_field":      False,
        "Tecplot":         False,
        "Paraview":        False,
        "CPK":             False,
    }

    fail = AeroResult(cl=None, cd=None, coords=pymead_coords)
    try:
        print("\nRunning MSES...")
        aero_data, logs = calculate_aero_data(
            conn=None,
            airfoil_coord_dir=tempfile.gettempdir(),
            airfoil_name=name,
            mea=mea,
            tool="MSES",
            mset_settings=mset,
            mses_settings=mses,
            mplot_settings=mplot,
            export_Cp=False,
            save_aero_data=True,
        )
        if not aero_data.get("converged"):
            print("---- MSES log tail ----")
            print(str(logs)[-3000:])
    except Exception as e:
        print(f"MSES exception: {e}")
        return fail

    if aero_data.get("errored_out"):    print("MSES errored out");      return fail
    if aero_data.get("timed_out"):      print("MSES timed out");        return fail
    if not aero_data.get("converged"):  print("MSES did not converge"); return fail

    cl, cd = aero_data["Cl"], aero_data["Cd"]
    if not (np.isfinite(cl) and np.isfinite(cd)):
        print("MSES returned non-finite Cl/Cd"); return fail

    print(f"Cl = {cl:+.5f}   Cd = {cd:.5f}")
    return AeroResult(cl=cl, cd=cd, coords=pymead_coords)


# Single element (legacy phase-1 path; also used for seed-only tests)
def run_mses(design,
             name="candidate_airfoil",
             alpha=0.0,
             mach=0.08,
             reynolds=0.7e6,
             seed_airfoil="",
             phase=1,
             aoa_phase3=0.0,
             plot_geometry=False,
             plot_comparison=False,
             target_cl=None):

    # Geometry: load seed -> decompose -> morph flat -> assemble loop
    x_seed, y_seed = load_airfoil_dat(seed_airfoil)
    x_common, camber_seed, thickness_seed, aoa_seed = get_seed(x_seed, y_seed)
    print(f"derotated to {np.degrees(aoa_seed):+.2f} deg (seed's detected angle, removed)")
    print(f"re-rotated to 0.00 deg (morphing flat; alpha={alpha} controls flow angle)")

    xu, yu, xl, yl, _, _, _ = new_airfoil(
        thickness_seed=thickness_seed,
        x_common=x_common,
        designParameters=design,
        n_points=160,
        smoothing_fac=None,
        aoa=0.0,
    )
    coords = get_coords(xu, xl, yu, yl, phase=phase, aoa_deg=aoa_phase3)

    if plot_geometry:
        plt.figure(figsize=(10, 4))
        plt.plot(coords[:, 0], coords[:, 1], lw=2)
        plt.axis("equal"); plt.grid(True)
        plt.xlabel("x/c"); plt.ylabel("y/c"); plt.title(name)
        plt.show()

    if plot_comparison:
        fig, axes = plt.subplots(1, 2, figsize=(14, 4))
        axes[0].plot(x_seed, y_seed)
        axes[0].set_title("Seed Airfoil"); axes[0].axis("equal"); axes[0].grid(True)
        axes[1].plot(coords[:, 0], coords[:, 1])
        axes[1].set_title("Morphed Airfoil"); axes[1].axis("equal"); axes[1].grid(True)
        plt.suptitle(f"{name} - geometry comparison"); plt.show()

    # Register with pymead (single element)
    dat_file = os.path.join(tempfile.gettempdir(), f"{name}_input.dat")
    np.savetxt(dat_file, coords)

    geo_col = GeometryCollection()
    polyline = geo_col.add_polyline(source=dat_file)
    airfoil = polyline.add_polyline_airfoil()
    mea = geo_col.add_mea([airfoil])
    pymead_coords = np.array(airfoil.coords)

    return _run_mses_on_mea(
        mea, pymead_coords, ["Airfoil-1"], name, alpha, mach, reynolds,
        target_cl=target_cl,
    )


# Multi-element
# An "element" is one airfoil in the MSES domain, described by a dict
# in the phase config:
#   morph element (shape driven by the BO design vector):
#       {"role": "morph", "seed_airfoil": <path>,
#        "place": "main" | "second",
#        "second_elm_loc": (h, v),   # only if place == "second"
#        "aoa_deg": 0.0}
#   fixed element (final geometry from a .dat):
#       {"role": "fixed", "coords_path": <path>,
#        "place": "main" | "second",
#        "second_elm_loc": (h, v),
#        "aoa_deg": 0.0}
# Exactly one morph element per phase (the BO design vector drives it).

def _element_to_coords(spec, design=None):
    """Turn one element spec into an (N,2) Selig coordinate loop."""
    place = spec.get("place", "main")
    aoa = spec.get("aoa_deg", 0.0)

    if spec["role"] == "morph":
        x_seed, y_seed = load_airfoil_dat(str(spec["seed_airfoil"]))
        x_common, _, thickness_seed, aoa_seed = get_seed(x_seed, y_seed)
        morph_aoa = 0.0 if spec.get("inherit_te_aoa", False) else aoa_seed
        xu, yu, xl, yl, _, _, _ = new_airfoil(
            thickness_seed=thickness_seed,
            x_common=x_common,
            designParameters=design,
            n_points=160,
            smoothing_fac=None,
            aoa=morph_aoa,
        )
        coords = get_coords(xu, xl, yu, yl, phase=1)

    elif spec["role"] == "fixed":
        x, y = load_airfoil_dat(str(spec["coords_path"]))
        coords = np.column_stack([x, y])

    else:
        raise ValueError(f"Unknown element role: {spec['role']}")

    # Placement: scale + translate to put a flap behind the main element.
    if place == "second":
        loc = spec.get("second_elm_loc",
                       (SECOND_ELM_LOC["horizontal"], SECOND_ELM_LOC["vertical"]))
        coords = scale_airfoil(coords, scale=0.435, origin=(0.0, 0.0))
        coords = translate_airfoil(coords, loc[0], loc[1])

    # Optional EXTRA rotation about this element's LE.
    if aoa != 0.0:
        coords = rotate_airfoil_phase3(coords, aoa,
                                       pivot=coords[int(np.argmin(coords[:, 0]))])

    return coords


def run_mses_elements(design, elements,
                      name="candidate_airfoil",
                      alpha=0.0,
                      mach=0.08,
                      reynolds=0.7e6,
                      plot_geometry=False,
                      plot_comparison=False,
                      target_cl=None):
    # Build coords for every element
    all_coords = []
    for spec in elements:
        d = design if spec["role"] == "morph" else None
        all_coords.append(_element_to_coords(spec, design=d))

    # Want the second "morph" element to inherit the first element's TE angle
    # apply the main element's TE angle as a rotation about morph;s LE
    from setup.geometry import trailing_edge_angle_from_coords
    main_idx = next((i for i, s in enumerate(elements)
                     if s.get("place", "main") == "main"), None)
    # find TE coordinate from main element
    if main_idx is not None:
        main_te = all_coords[main_idx][int(np.argmax(all_coords[main_idx][:, 0]))]
        for i, spec in enumerate(elements):
            if spec.get("place") == "second" and "te_offset" in spec:
                dx, dy = spec["te_offset"]
                le = all_coords[i][int(np.argmin(all_coords[i][:, 0]))]
                target = main_te + np.array([dx, dy])
                all_coords[i] = translate_airfoil(
                    all_coords[i], target[0] - le[0], target[1] - le[1]
                )
    # find TE angle of the main element to align with LE of second elment
    if main_idx is not None:
        te_angle = trailing_edge_angle_from_coords(all_coords[main_idx])
        print(f"main element TE angle: {te_angle:+.2f} deg (applied to flap)")
        for i, spec in enumerate(elements):
            if spec.get("place") == "second" and spec.get("inherit_te_aoa", False):
                le = all_coords[i][int(np.argmin(all_coords[i][:, 0]))]
                all_coords[i] = rotate_airfoil_phase3(all_coords[i], te_angle, pivot=le)

    if plot_geometry:
        plt.figure(figsize=(10, 4))
        for c in all_coords:
            plt.plot(c[:, 0], c[:, 1], lw=2)
        plt.axis("equal"); plt.grid(True)
        plt.xlabel("x/c"); plt.ylabel("y/c"); plt.title(name)
        plt.show()

    # Register every element with pymead
    geo_col = GeometryCollection()
    airfoils = []
    for i, coords in enumerate(all_coords):
        dat_i = os.path.join(tempfile.gettempdir(), f"{name}_el{i}.dat")
        np.savetxt(dat_i, coords)
        pl = geo_col.add_polyline(source=dat_i)
        airfoils.append(pl.add_polyline_airfoil())
    mea = geo_col.add_mea(airfoils)
    pymead_coords = np.vstack([np.array(a.coords) for a in airfoils])

    names = [f"Airfoil-{i+1}" for i in range(len(airfoils))]
    return _run_mses_on_mea(
        mea, pymead_coords, names, name, alpha, mach, reynolds,
        target_cl=target_cl,
    )